package com.example.test;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ChapterReadActivity extends AppCompatActivity {

    private TextView tvComicName, tvChapterName, tvUpdateDate, tvBack;
    private RecyclerView recyclerImages;
    private ChapterImageAdapter imageAdapter;
    private List<Integer> imageList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chapter_read);

        // Ánh xạ views
        tvComicName = findViewById(R.id.tvComicNameRead);
        tvChapterName = findViewById(R.id.tvChapterNameRead);
        tvUpdateDate = findViewById(R.id.tvUpdateDateRead);
        tvBack = findViewById(R.id.tvBackRead);
        recyclerImages = findViewById(R.id.recyclerChapterImages);

        // Nhận dữ liệu từ Intent
        Intent intent = getIntent();
        String comicName = intent.getStringExtra("comicName");
        String chapterName = intent.getStringExtra("chapterName");
        String updateDate = intent.getStringExtra("updateDate");

        // Hiển thị thông tin
        tvComicName.setText(comicName != null ? comicName : "Thợ Săn Hạng S");
        tvChapterName.setText(chapterName != null ? chapterName : "Chương 114");
        tvUpdateDate.setText(updateDate != null ? updateDate : "Cập nhật: 03/09/2025");

        // Dữ liệu mẫu - danh sách ảnh truyện (sử dụng ảnh có sẵn)
        imageList = new ArrayList<>();
        imageList.add(R.drawable.anh1);
        imageList.add(R.drawable.anh1);
        imageList.add(R.drawable.anh1);
        imageList.add(R.drawable.anh1);
        imageList.add(R.drawable.anh1);
        // Bạn có thể thêm nhiều ảnh khác nếu có

        // Setup RecyclerView
        imageAdapter = new ChapterImageAdapter(this, imageList);
        recyclerImages.setLayoutManager(new LinearLayoutManager(this));
        recyclerImages.setAdapter(imageAdapter);

        // Xử lý nút quay lại
        tvBack.setOnClickListener(v -> finish());
    }
}