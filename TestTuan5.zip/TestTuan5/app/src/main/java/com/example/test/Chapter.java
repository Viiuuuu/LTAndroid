package com.example.test;

public class Chapter {
    private String title;
    private String views;
    private String comments;
    private String status; // "HẾT" hoặc ""

    public Chapter(String title, String views, String comments, String status) {
        this.title = title;
        this.views = views;
        this.comments = comments;
        this.status = status;
    }

    public String getTitle() {
        return title;
    }

    public String getViews() {
        return views;
    }

    public String getComments() {
        return comments;
    }

    public String getStatus() {
        return status;
    }
}