package com.example.test;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Profile extends AppCompatActivity {

	private static final String PREFS_NAME = "LoginPrefs";
	private static final String KEY_IS_LOGGED_IN = "isLoggedIn";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_profile);

		TextView tvUsername = findViewById(R.id.tvUsername);
		TextView tvDob = findViewById(R.id.tvDob);
		TextView tvGender = findViewById(R.id.tvGender);
		TextView tvEmail = findViewById(R.id.tvEmail);
		ImageButton btnSettings = findViewById(R.id.btnSettingsProfile);
		TextView tvBack = findViewById(R.id.tvBack);

		Intent intent = getIntent();
		String username = intent.getStringExtra("username");
		String dob = intent.getStringExtra("dob");
		String gender = intent.getStringExtra("gender");
		String email = intent.getStringExtra("email");

		tvUsername.setText(username != null ? username : "");
		tvDob.setText(dob != null ? dob : "");
		tvGender.setText(gender != null ? gender : "");
		tvEmail.setText(email != null ? email : "");

		// ✅ NÚT SETTINGS - ĐĂNG XUẤT
		btnSettings.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				showLogoutDialog();
			}
		});

		// ✅ NÚT BACK - QUAY VỀ MAINACTIVITY
		tvBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish(); // Đóng Profile và quay về MainActivity
			}
		});
	}

	// ✅ HIỂN THỊ DIALOG ĐĂNG XUẤT
	private void showLogoutDialog() {
		new AlertDialog.Builder(this)
				.setTitle("Đăng xuất")
				.setMessage("Bạn có muốn đăng xuất không?")
				.setPositiveButton("Có", (dialog, which) -> {
					logout();
				})
				.setNegativeButton("Không", null)
				.show();
	}

	// ✅ ĐĂNG XUẤT
	private void logout() {
		SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
		SharedPreferences.Editor editor = sharedPreferences.edit();
		editor.putBoolean(KEY_IS_LOGGED_IN, false);
		editor.clear(); // Xóa tất cả dữ liệu
		editor.apply();

		Toast.makeText(this, "Đã đăng xuất", Toast.LENGTH_SHORT).show();

		// Quay về MainActivity
		Intent backToMain = new Intent(Profile.this, MainActivity.class);
		backToMain.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(backToMain);
		finish();
	}
}