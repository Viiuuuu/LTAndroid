package com.example.test;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ChapterListActivity extends AppCompatActivity {

    private TextView tvComicTitle, tvBack, tvReadFromStart;
    private RecyclerView recyclerChapters;
    private ChapterAdapter chapterAdapter;
    private List<Chapter> chapterList;
    private String comicTitle; // ✅ Thêm biến lưu tên truyện

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chapter_list);

        tvComicTitle = findViewById(R.id.tvComicTitle);
        tvBack = findViewById(R.id.tvBackChapter);
        tvReadFromStart = findViewById(R.id.tvReadFromStart);
        recyclerChapters = findViewById(R.id.recyclerChapters);

        // ✅ Lưu tên truyện
        Intent intent = getIntent();
        comicTitle = intent.getStringExtra("comicTitle");

        tvComicTitle.setText(comicTitle != null ? comicTitle : "DANH SÁCH CHƯƠNG");

        // Dữ liệu mẫu cho danh sách chương
        chapterList = new ArrayList<>();
        chapterList.add(new Chapter("[SS2] Lại Một Lần [...] – Chap 114", "11.2K", "88", "HẾT"));
        chapterList.add(new Chapter("[SS2] Lại Một Lần [...] – Chap 113", "7.8K", "64", ""));
        chapterList.add(new Chapter("[SS2] Lại Một Lần [...] – Chap 112", "7.6K", "89", ""));
        chapterList.add(new Chapter("[SS2] Lại Một Lần [...] – Chap 111", "7.4K", "79", ""));
        chapterList.add(new Chapter("[SS2] Lại Một Lần [...] – Chap 110", "6.1K", "71", ""));
        chapterList.add(new Chapter("[SS2] Lại Một Lần [...] – Chap 109", "9.1K", "85", ""));

        // Setup RecyclerView
        chapterAdapter = new ChapterAdapter(this, chapterList);
        recyclerChapters.setLayoutManager(new LinearLayoutManager(this));
        recyclerChapters.setAdapter(chapterAdapter);

        // Xử lý click
        tvBack.setOnClickListener(v -> finish());

        // ✅ Xem từ đầu
        tvReadFromStart.setOnClickListener(v -> {
            if (!chapterList.isEmpty()) {
                openChapter(chapterList.get(chapterList.size() - 1)); // Mở chương đầu tiên
            }
        });

        // ✅ Click vào chương để đọc
        chapterAdapter.setOnChapterClickListener(chapter -> {
            openChapter(chapter);
        });
    }

    // ✅ Method mở màn hình đọc chương
    private void openChapter(Chapter chapter) {
        Intent intent = new Intent(ChapterListActivity.this, ChapterReadActivity.class);
        intent.putExtra("comicName", comicTitle);
        intent.putExtra("chapterName", chapter.getTitle());
        intent.putExtra("updateDate", "Cập nhật: 03/09/2025");
        startActivity(intent);
    }
}